<?php

$sever="localhost";
$user="root";
$password="";
$database="negocios1";
$port=3307;

$con=mysqli_connect($sever,$user,$password,$database,$port);
// if($con){
//     echo("yes");
// }else{
//     echo("no");
// }