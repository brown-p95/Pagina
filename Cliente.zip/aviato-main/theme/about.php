<?php
include("header.html");
?>

<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="en">


<body id="body">

<!-- Start Top Header Bar -->



<!-- Main Menu Section -->


<section class="page-header">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="content">
					<h1 class="page-name">Acerca de nostros</h1>
					<ol class="breadcrumb">
						<li><a href="index.html">Inicio</a></li>
						<li class="active">acerca de nosotros</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="about section">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<img class="img-responsive" src="images/about/about.jpg">
			</div>
			<div class="col-md-6">
				<h2 class="mt-40">TOGUs</h2>
				<p>Somos una empresa dedicada a la moda y la buena sustentibilidad del mismo dando asi la mejores prendas al mejor precio </p>
				<p>la tienda online que mas se enfoca en la moda de las mujeres dando un gran cambio de apariencia y belleza.</p>
				<p>empresa nacida den aguascalientes, ags desde el 2022 llevando acabo </p>
				<a href="contact.php" class="btn btn-main mt-20">Descargar perfil de la empresa</a>
			</div>
		</div>
		<div class="row mt-40">
			<div class="col-md-3 text-center">
				<img src="images/about/awards-logo.png">
			</div>
			<div class="col-md-3 text-center">
				<img src="images/about/awards-logo.png">
			</div>
			<div class="col-md-3 text-center">
				<img src="images/about/awards-logo.png">
			</div>
			<div class="col-md-3 text-center">
				<img src="images/about/awards-logo.png">
			</div>
		</div>
	</div>
</section>
<section class="team-members ">
	<div class="container">
		<div class="row">
			<div class="title"><h2>Miembros del equipo</h2></div>
		</div>
		<div class="row">
			<div class="col-md-3">
				<div class="team-member text-center">
					<img class="img-circle" src="images/team/team-1.jpg">
					<h4>Cecilia</h4>
					<p>Fundadora</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="team-member text-center">
					<img class="img-circle" src="images/team/team-2.jpg">
					<h4>Veronica</h4>
					<p>Desarrolladora</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="team-member text-center">
					<img class="img-circle" src="images/team/team-3.jpg">
					<h4>Paula</h4>
					<p>Gerente de tienda</p>
				</div>
			</div>
			<div class="col-md-3">
				<div class="team-member text-center">
					<img class="img-circle" src="images/team/team-1.jpg">
					<h4>Pablo</h4>
					<p>Gerente de tienda</p>
				</div>
			</div>
		</div>
	</div>
</section>





<footer class="footer section text-center">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="social-media">
					<li>
						<a href="https://www.facebook.com/themefisher">
							<i class="tf-ion-social-facebook"></i>
						</a>
					</li>
					<li>
						<a href="https://www.instagram.com/themefisher">
							<i class="tf-ion-social-instagram"></i>
						</a>
					</li>
					<li>
						<a href="https://www.twitter.com/themefisher">
							<i class="tf-ion-social-twitter"></i>
						</a>
					</li>
					<li>
						<a href="https://www.pinterest.com/themefisher/">
							<i class="tf-ion-social-pinterest"></i>
						</a>
					</li>
				</ul>
				<ul class="footer-menu text-uppercase">
					<li>
						<a href="contact.html">Contacto</a>
					</li>
					<li>
						<a href="shop.html">Compra</a>
					</li>
					<li>
						<a href="pricing.html">Precios</a>
					</li>
					<li>
						<a href="contact.html">Politica de privacidad</a>
					</li>
				</ul>
				<p class="copyright-text">Copyright &copy;2021, Designed &amp; Developed by TOGU</p>
			</div>
		</div>
	</div>
</footer>

    <!-- 
    Essential Scripts
    =====================================-->
    
  
  </body>
  </html>