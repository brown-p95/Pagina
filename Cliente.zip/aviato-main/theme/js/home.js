const logout=document.getElementById("logout").addEventListener("click",salir());;


const salir=()=>{
    window.location.href("../index.html");
}