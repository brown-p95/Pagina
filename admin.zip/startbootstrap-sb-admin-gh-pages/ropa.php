<?php

include("header.html");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ropa y precio</title>
</head>
<body>
<div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>img</th>
                                            <th>Nombre</th>
                                            <th>categoria</th>  
                                            <th>descripcion</th>
                                            
                                           
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th><img src="images/" alt=""></th>
                                            <th>mom-jeans</th>
                                            <th>Jeans/th>
                                            <th>tiro alto</th>
                                           
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <tr>
                                        <th><img src="" alt=""></th>
                                            <th>vintaje jeans</th>
                                            <th>Jeans</th>
                                            <th>tiro alto</th>
                                        </tr>
                                        <tr>
                                        <th><img src="" alt=""></th>
                                            <th>mom-jeans</th>
                                            <th>Jeans/th>
                                            <th>tiro alto</th>
                                        </tr>
                                        <tr>
                                        <th><img src="" alt=""></th>
                                            <th>mom-jeans</th>
                                            <th>Jeans/th>
                                            <th>tiro alto</th>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
</body>
</html>